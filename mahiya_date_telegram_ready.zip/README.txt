اتصال سایت مهیا به تلگرام

1) یک Cloudflare Worker بساز و محتوای worker.js را داخلش قرار بده و Deploy کن.
2) در Variables/Secrets دو مقدار بساز:
BOT_TOKEN = توکن جدید بات (Secret)
CHAT_ID = 7514736662
3) آدرس Worker را کپی کن.
4) در index.html عبارت PASTE_YOUR_WORKER_URL_HERE را با آدرس Worker عوض کن.
5) index.html را جایگزین فایل قبلی در GitHub کن.

بعد از زدن «ثبت قرار ❤️»، انتخاب‌های مهیا به تلگرام تو ارسال می‌شود.
توکن را داخل GitHub یا index.html قرار نده.
