const ALLOWED_ORIGIN = "*";

export default {
  async fetch(request, env) {
    const cors = {
      "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type"
    };

    if (request.method === "OPTIONS") return new Response(null, {status:204, headers:cors});
    if (request.method !== "POST") return new Response("OK", {status:200, headers:cors});

    try {
      const data = await request.json();
      const text = `❤️ مهیا جواب داد!

📅 روز: ${data.date || "-"}
⏰ ساعت: ${data.time || "-"}
📍 نوع قرار: ${data.type || "-"}`;

      const r = await fetch(`https://api.telegram.org/bot${env.BOT_TOKEN}/sendMessage`, {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify({chat_id: env.CHAT_ID, text})
      });

      return new Response(r.ok ? "sent" : "Telegram error", {
        status: r.ok ? 200 : 502, headers: cors
      });
    } catch (e) {
      return new Response("Bad request", {status:400, headers:cors});
    }
  }
};
